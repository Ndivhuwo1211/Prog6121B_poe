using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

/// <summary>Organisers capture finish times and positions; Participants view their own race history.</summary>
public class ResultsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public ResultsController(RaceDayDbContext db)
    {
        _db = db;
    }

    /// <summary>Captures and publishes a finish time and position for an enrolled Participant.</summary>
    /// <response code="201">The created result.</response>
    /// <response code="400">Invalid values (e.g. position greater than total finishers) or the enrolment was cancelled.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Enrolment does not exist.</response>
    /// <response code="409">A result already exists for this enrolment.</response>
    [HttpPost("api/enrolments/{enrolmentId:int}/results")]
    [SessionAuthorize(RoleNames.Organiser)]
    [ProducesResponseType(typeof(ResultResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> CreateResult(int enrolmentId, [FromBody] ResultRequest request)
    {
        var enrolment = await _db.Enrolments
            .Include(e => e.Event)
            .Include(e => e.Result)
            .FirstOrDefaultAsync(e => e.EnrolmentId == enrolmentId);

        if (enrolment is null)
            return ProblemResponse(404, "Not found", "Enrolment not found.");
        if (enrolment.Event!.OrganiserId != CurrentUserId)
            return ProblemResponse(403, "Forbidden", "You can only capture results for events that you created.");
        if (enrolment.Result is not null)
            return ProblemResponse(409, "Conflict", "A result already exists for this enrolment. Use PUT /api/results/{id} to change it.");
        if (enrolment.Status == EnrolmentStatuses.Cancelled)
            return ProblemResponse(400, "Invalid enrolment", "Results cannot be captured for a cancelled enrolment.");

        var validationError = ValidateResult(request);
        if (validationError is not null) return validationError;

        var result = new RaceResult
        {
            EnrolmentId = enrolmentId,
            FinishTime = request.FinishTime,
            FinishPosition = request.FinishPosition,
            TotalFinishers = request.TotalFinishers,
            PublishedAt = DateTime.Now
        };

        _db.Results.Add(result);
        await _db.SaveChangesAsync();

        var response = await _db.Results.Where(r => r.ResultId == result.ResultId).ProjectToResponse().SingleAsync();
        return Created($"/api/events/{enrolment.EventId}/results", response);
    }

    /// <summary>Updates a previously captured result. Only the owning Organiser may do this.</summary>
    /// <response code="200">The updated result.</response>
    /// <response code="400">Invalid values.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Result does not exist.</response>
    [HttpPut("api/results/{id:int}")]
    [SessionAuthorize(RoleNames.Organiser)]
    [ProducesResponseType(typeof(ResultResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateResult(int id, [FromBody] ResultRequest request)
    {
        var result = await _db.Results
            .Include(r => r.Enrolment).ThenInclude(e => e!.Event)
            .FirstOrDefaultAsync(r => r.ResultId == id);

        if (result is null)
            return ProblemResponse(404, "Not found", "Result not found.");
        if (result.Enrolment!.Event!.OrganiserId != CurrentUserId)
            return ProblemResponse(403, "Forbidden", "You can only change results for events that you created.");

        var validationError = ValidateResult(request);
        if (validationError is not null) return validationError;

        result.FinishTime = request.FinishTime;
        result.FinishPosition = request.FinishPosition;
        result.TotalFinishers = request.TotalFinishers;
        result.PublishedAt = DateTime.Now;
        await _db.SaveChangesAsync();

        var response = await _db.Results.Where(r => r.ResultId == id).ProjectToResponse().SingleAsync();
        return Ok(response);
    }

    /// <summary>Returns the logged-in Participant's personal race history across all published results.</summary>
    /// <response code="200">Results with event name, date, category, finish time and position (most recent first).</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Participants can use this endpoint.</response>
    [HttpGet("api/users/me/results")]
    [SessionAuthorize(RoleNames.Participant)]
    [ProducesResponseType(typeof(List<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMyResults()
    {
        var results = await _db.Results
            .Where(r => r.Enrolment!.ParticipantId == CurrentUserId && r.PublishedAt != null)
            .OrderByDescending(r => r.Enrolment!.Event!.EventDate)
            .ProjectToResponse()
            .ToListAsync();
        return Ok(results);
    }

    /// <summary>Lists all captured results for an event, ordered by finishing position. Owning Organiser only.</summary>
    /// <response code="200">The event's results.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpGet("api/events/{eventId:int}/results")]
    [SessionAuthorize(RoleNames.Organiser)]
    [ProducesResponseType(typeof(List<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEventResults(int eventId)
    {
        var (_, error) = await LoadOwnedEventAsync(_db, eventId);
        if (error is not null) return error;

        var results = await _db.Results
            .Where(r => r.Enrolment!.EventId == eventId)
            .OrderBy(r => r.FinishPosition)
            .ProjectToResponse()
            .ToListAsync();
        return Ok(results);
    }

    private IActionResult? ValidateResult(ResultRequest request)
    {
        if (request.FinishTime is null || request.FinishTime <= TimeSpan.Zero)
            return ProblemResponse(400, "Invalid finish time", "finishTime must be greater than 00:00:00.");
        if (request.FinishPosition > request.TotalFinishers)
            return ProblemResponse(400, "Invalid position", "finishPosition cannot be greater than totalFinishers.");
        return null;
    }
}
