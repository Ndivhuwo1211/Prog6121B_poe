using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Create, view, update and delete race events.</summary>
[Route("api/events")]
public class EventsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly IFileStorageService _storage;

    public EventsController(RaceDayDbContext db, IFileStorageService storage)
    {
        _db = db;
        _storage = storage;
    }

    /// <summary>Lists upcoming events with optional filters. Public.</summary>
    /// <param name="eventType">Filter by type: Run, Walk or Cycle.</param>
    /// <param name="location">Filter by location (contains).</param>
    /// <param name="search">Filter by event name (contains).</param>
    /// <param name="fromDate">Only events on or after this date.</param>
    /// <param name="toDate">Only events on or before this date.</param>
    /// <param name="includePast">Set true to include events that have already taken place.</param>
    /// <response code="200">Matching events, soonest first.</response>
    /// <response code="400">Invalid eventType filter.</response>
    [HttpGet]
    [ProducesResponseType(typeof(List<EventResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetEvents(
        [FromQuery] string? eventType,
        [FromQuery] string? location,
        [FromQuery] string? search,
        [FromQuery] DateTime? fromDate,
        [FromQuery] DateTime? toDate,
        [FromQuery] bool includePast = false)
    {
        var query = _db.Events.AsQueryable();

        if (!includePast)
        {
            var now = DateTime.Now;
            query = query.Where(e => e.EventDate >= now);
        }

        if (!string.IsNullOrWhiteSpace(eventType))
        {
            var type = EventTypes.Normalise(eventType);
            if (type is null)
                return ProblemResponse(400, "Invalid filter", "eventType must be Run, Walk or Cycle.");
            query = query.Where(e => e.EventType == type);
        }

        if (!string.IsNullOrWhiteSpace(location))
        {
            var loc = location.Trim();
            query = query.Where(e => e.Location.Contains(loc));
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(e => e.Name.Contains(term));
        }

        if (fromDate.HasValue) query = query.Where(e => e.EventDate >= fromDate.Value);
        if (toDate.HasValue) query = query.Where(e => e.EventDate <= toDate.Value);

        var events = await query.OrderBy(e => e.EventDate).ProjectToResponse().ToListAsync();
        return Ok(events);
    }

    /// <summary>Lists every event created by the logged-in Organiser (used for the Organiser dashboard).</summary>
    /// <response code="200">The Organiser's events, including enrolment counts.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Participants cannot use this endpoint.</response>
    [HttpGet("mine")]
    [SessionAuthorize(RoleNames.Organiser)]
    [ProducesResponseType(typeof(List<EventResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMyEvents()
    {
        var events = await _db.Events
            .Where(e => e.OrganiserId == CurrentUserId)
            .OrderBy(e => e.EventDate)
            .ProjectToResponse()
            .ToListAsync();
        return Ok(events);
    }

    /// <summary>Returns full details of one event, including its categories. Public.</summary>
    /// <response code="200">The event and its categories.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(EventDetailResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEventById(int id)
    {
        var ev = await _db.Events.Where(e => e.EventId == id).ProjectToResponse().FirstOrDefaultAsync();
        if (ev is null)
            return ProblemResponse(404, "Not found", "Event not found.");

        var categories = await _db.Categories
            .Where(c => c.EventId == id)
            .OrderBy(c => c.Name)
            .ToListAsync();

        return Ok(new EventDetailResponse(
            ev.EventId, ev.OrganiserId, ev.OrganiserName, ev.Name, ev.Description, ev.EventDate,
            ev.Location, ev.DistanceKm, ev.EventType, ev.BannerImageUrl, ev.EnrolmentCount,
            categories.Select(c => c.ToResponse()).ToList()));
    }

    /// <summary>Creates a new event owned by the logged-in Organiser.</summary>
    /// <response code="201">The created event.</response>
    /// <response code="400">Validation failed (e.g. eventType not Run/Walk/Cycle).</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Organisers can create events.</response>
    [HttpPost]
    [SessionAuthorize(RoleNames.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> CreateEvent([FromBody] EventRequest request)
    {
        var type = EventTypes.Normalise(request.EventType);
        if (type is null)
            return ProblemResponse(400, "Invalid event type", "eventType must be Run, Walk or Cycle.");

        var ev = new RaceEvent
        {
            OrganiserId = CurrentUserId,
            Name = request.Name.Trim(),
            Description = request.Description.Trim(),
            EventDate = request.EventDate!.Value,
            Location = request.Location.Trim(),
            DistanceKm = request.DistanceKm,
            EventType = type,
            CreatedAt = DateTime.Now
        };

        _db.Events.Add(ev);
        await _db.SaveChangesAsync();

        var response = await _db.Events.Where(e => e.EventId == ev.EventId).ProjectToResponse().SingleAsync();
        return CreatedAtAction(nameof(GetEventById), new { id = ev.EventId }, response);
    }

    /// <summary>Updates an event. Only the Organiser who created it may do this.</summary>
    /// <response code="200">The updated event.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpPut("{id:int}")]
    [SessionAuthorize(RoleNames.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateEvent(int id, [FromBody] EventRequest request)
    {
        var (ev, error) = await LoadOwnedEventAsync(_db, id);
        if (error is not null) return error;

        var type = EventTypes.Normalise(request.EventType);
        if (type is null)
            return ProblemResponse(400, "Invalid event type", "eventType must be Run, Walk or Cycle.");

        ev!.Name = request.Name.Trim();
        ev.Description = request.Description.Trim();
        ev.EventDate = request.EventDate!.Value;
        ev.Location = request.Location.Trim();
        ev.DistanceKm = request.DistanceKm;
        ev.EventType = type;
        await _db.SaveChangesAsync();

        var response = await _db.Events.Where(e => e.EventId == id).ProjectToResponse().SingleAsync();
        return Ok(response);
    }

    /// <summary>Deletes an event (and its categories). Only the owning Organiser may do this.</summary>
    /// <response code="204">Event deleted.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event does not exist.</response>
    /// <response code="409">The event already has enrolments and cannot be deleted.</response>
    [HttpDelete("{id:int}")]
    [SessionAuthorize(RoleNames.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var (ev, error) = await LoadOwnedEventAsync(_db, id);
        if (error is not null) return error;

        if (await _db.Enrolments.AnyAsync(e => e.EventId == id))
            return ProblemResponse(409, "Conflict", "This event already has enrolments and cannot be deleted.");

        await _db.Entry(ev!).Collection(e => e.Categories).LoadAsync();
        _db.Events.Remove(ev!);
        await _db.SaveChangesAsync();

        return NoContent();
    }

    /// <summary>Uploads or replaces the banner image for an event (JPG, PNG or WEBP, max 5 MB).</summary>
    /// <response code="200">The URL of the stored banner.</response>
    /// <response code="400">No file, wrong type, or file too large.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpPost("{id:int}/banner")]
    [SessionAuthorize(RoleNames.Organiser)]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(UploadResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UploadBanner(int id, IFormFile file, CancellationToken cancellationToken)
    {
        var (ev, error) = await LoadOwnedEventAsync(_db, id);
        if (error is not null) return error;

        var fileError = ImageUploadRules.Validate(file);
        if (fileError is not null)
            return ProblemResponse(400, "Invalid file", fileError);

        ev!.BannerImageUrl = await _storage.SaveAsync(file, "banners", cancellationToken);
        await _db.SaveChangesAsync(cancellationToken);

        return Ok(new UploadResponse(ev.BannerImageUrl));
    }
}
