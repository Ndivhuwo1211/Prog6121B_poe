using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

/// <summary>Participants entering events; Organisers viewing and managing those enrolments.</summary>
public class EnrolmentsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public EnrolmentsController(RaceDayDbContext db)
    {
        _db = db;
    }

    /// <summary>Enrols the logged-in Participant in an event under the chosen category.</summary>
    /// <remarks>New enrolments start with the status "Pending". The category must belong to the event.</remarks>
    /// <response code="201">The new enrolment.</response>
    /// <response code="400">Invalid category for this event, or the event has already taken place.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Participants can enrol.</response>
    /// <response code="404">Event does not exist.</response>
    /// <response code="409">The Participant is already enrolled in this event.</response>
    [HttpPost("api/events/{eventId:int}/enrolments")]
    [SessionAuthorize(RoleNames.Participant)]
    [ProducesResponseType(typeof(EnrolmentResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Enrol(int eventId, [FromBody] EnrolRequest request)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventId == eventId);
        if (ev is null)
            return ProblemResponse(404, "Not found", "Event not found.");

        var category = await _db.Categories
            .FirstOrDefaultAsync(c => c.CategoryId == request.CategoryId && c.EventId == eventId);
        if (category is null)
            return ProblemResponse(400, "Invalid category", "The selected category does not belong to this event.");

        if (ev.EventDate < DateTime.Now)
            return ProblemResponse(400, "Event closed", "This event has already taken place.");

        if (await _db.Enrolments.AnyAsync(e => e.EventId == eventId && e.ParticipantId == CurrentUserId))
            return ProblemResponse(409, "Conflict", "You are already enrolled in this event.");

        var enrolment = new Enrolment
        {
            ParticipantId = CurrentUserId,
            EventId = eventId,
            CategoryId = category.CategoryId,
            EnrolmentDate = DateTime.Now,
            Status = EnrolmentStatuses.Pending
        };

        _db.Enrolments.Add(enrolment);
        await _db.SaveChangesAsync();

        var response = await _db.Enrolments
            .Where(e => e.EnrolmentId == enrolment.EnrolmentId)
            .ProjectToResponse()
            .SingleAsync();

        return Created("/api/users/me/enrolments", response);
    }

    /// <summary>Lists every event the logged-in Participant has enrolled in, with status.</summary>
    /// <response code="200">The Participant's enrolments, soonest event first.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Participants can use this endpoint.</response>
    [HttpGet("api/users/me/enrolments")]
    [SessionAuthorize(RoleNames.Participant)]
    [ProducesResponseType(typeof(List<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMyEnrolments()
    {
        var enrolments = await _db.Enrolments
            .Where(e => e.ParticipantId == CurrentUserId)
            .OrderBy(e => e.Event!.EventDate)
            .ProjectToResponse()
            .ToListAsync();
        return Ok(enrolments);
    }

    /// <summary>Lists all enrolments for an event. Only the owning Organiser may do this.</summary>
    /// <response code="200">Enrolments including participant name, category and status.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpGet("api/events/{eventId:int}/enrolments")]
    [SessionAuthorize(RoleNames.Organiser)]
    [ProducesResponseType(typeof(List<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEventEnrolments(int eventId)
    {
        var (_, error) = await LoadOwnedEventAsync(_db, eventId);
        if (error is not null) return error;

        var enrolments = await _db.Enrolments
            .Where(e => e.EventId == eventId)
            .OrderBy(e => e.EnrolmentDate)
            .ProjectToResponse()
            .ToListAsync();
        return Ok(enrolments);
    }

    /// <summary>Changes an enrolment's status (Pending, Confirmed or Cancelled). Owning Organiser only.</summary>
    /// <response code="200">The updated enrolment.</response>
    /// <response code="400">Unknown status.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Enrolment does not exist.</response>
    [HttpPut("api/enrolments/{id:int}/status")]
    [SessionAuthorize(RoleNames.Organiser)]
    [ProducesResponseType(typeof(EnrolmentResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateEnrolmentStatusRequest request)
    {
        var enrolment = await _db.Enrolments.Include(e => e.Event).FirstOrDefaultAsync(e => e.EnrolmentId == id);
        if (enrolment is null)
            return ProblemResponse(404, "Not found", "Enrolment not found.");
        if (enrolment.Event!.OrganiserId != CurrentUserId)
            return ProblemResponse(403, "Forbidden", "You can only manage enrolments for events that you created.");

        var status = EnrolmentStatuses.Normalise(request.Status);
        if (status is null)
            return ProblemResponse(400, "Invalid status", "Status must be Pending, Confirmed or Cancelled.");

        enrolment.Status = status;
        await _db.SaveChangesAsync();

        var response = await _db.Enrolments.Where(e => e.EnrolmentId == id).ProjectToResponse().SingleAsync();
        return Ok(response);
    }

    /// <summary>Cancels (removes) the logged-in Participant's own enrolment.</summary>
    /// <response code="204">Enrolment removed.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not a Participant, or the enrolment belongs to someone else.</response>
    /// <response code="404">Enrolment does not exist.</response>
    /// <response code="409">A result has already been recorded for this enrolment.</response>
    [HttpDelete("api/enrolments/{id:int}")]
    [SessionAuthorize(RoleNames.Participant)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> CancelEnrolment(int id)
    {
        var enrolment = await _db.Enrolments.Include(e => e.Result).FirstOrDefaultAsync(e => e.EnrolmentId == id);
        if (enrolment is null)
            return ProblemResponse(404, "Not found", "Enrolment not found.");
        if (enrolment.ParticipantId != CurrentUserId)
            return ProblemResponse(403, "Forbidden", "You can only cancel your own enrolments.");
        if (enrolment.Result is not null)
            return ProblemResponse(409, "Conflict", "A result has already been recorded, so this enrolment cannot be cancelled.");

        _db.Enrolments.Remove(enrolment);
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
