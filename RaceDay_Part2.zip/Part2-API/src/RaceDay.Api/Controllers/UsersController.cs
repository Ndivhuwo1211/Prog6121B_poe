using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Security;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>The logged-in user's own profile (both roles).</summary>
[Route("api/users")]
[SessionAuthorize]
public class UsersController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly IFileStorageService _storage;

    public UsersController(RaceDayDbContext db, IFileStorageService storage)
    {
        _db = db;
        _storage = storage;
    }

    /// <summary>Returns the logged-in user's profile.</summary>
    /// <response code="200">The user's profile.</response>
    /// <response code="401">Not logged in.</response>
    [HttpGet("me")]
    [ProducesResponseType(typeof(UserResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetMe()
    {
        var user = await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.UserId == CurrentUserId);
        if (user is null)
            return ProblemResponse(401, "Unauthorized", "Your account no longer exists.");
        return Ok(user.ToResponse());
    }

    /// <summary>Updates the logged-in user's first name, last name and phone number.</summary>
    /// <response code="200">The updated profile.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    [HttpPut("me")]
    [ProducesResponseType(typeof(UserResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UpdateMe([FromBody] UpdateProfileRequest request)
    {
        var user = await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.UserId == CurrentUserId);
        if (user is null)
            return ProblemResponse(401, "Unauthorized", "Your account no longer exists.");

        user.FirstName = request.FirstName.Trim();
        user.LastName = request.LastName.Trim();
        user.PhoneNumber = request.PhoneNumber?.Trim();
        await _db.SaveChangesAsync();

        return Ok(user.ToResponse());
    }

    /// <summary>Uploads or replaces the logged-in user's profile picture (JPG, PNG or WEBP, max 5 MB).</summary>
    /// <response code="200">The URL of the stored picture.</response>
    /// <response code="400">No file, wrong type, or file too large.</response>
    /// <response code="401">Not logged in.</response>
    [HttpPost("me/profile-picture")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(UploadResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UploadProfilePicture(IFormFile file, CancellationToken cancellationToken)
    {
        var error = ImageUploadRules.Validate(file);
        if (error is not null)
            return ProblemResponse(400, "Invalid file", error);

        var user = await _db.Users.FirstOrDefaultAsync(u => u.UserId == CurrentUserId, cancellationToken);
        if (user is null)
            return ProblemResponse(401, "Unauthorized", "Your account no longer exists.");

        user.ProfilePictureUrl = await _storage.SaveAsync(file, "profiles", cancellationToken);
        await _db.SaveChangesAsync(cancellationToken);

        return Ok(new UploadResponse(user.ProfilePictureUrl));
    }
}
