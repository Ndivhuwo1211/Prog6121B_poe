using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Registration, login and logout.</summary>
[Route("api/auth")]
public class AuthController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly IPasswordService _passwords;
    private readonly IConfiguration _config;

    public AuthController(RaceDayDbContext db, IPasswordService passwords, IConfiguration config)
    {
        _db = db;
        _passwords = passwords;
        _config = config;
    }

    /// <summary>Registers a new Organiser or Participant account.</summary>
    /// <remarks>
    /// Participants can self-register. To stop anyone from granting themselves Organiser rights,
    /// registering as an Organiser also requires the secret <c>organiserCode</c> configured on the server.
    /// The password is hashed (PBKDF2 + salt) before it is stored.
    /// </remarks>
    /// <response code="201">Account created. Returns the new user (never the password).</response>
    /// <response code="400">Validation failed (e.g. invalid email, short password, unknown role).</response>
    /// <response code="403">Organiser registration code missing or incorrect.</response>
    /// <response code="409">An account with this email already exists.</response>
    [HttpPost("register")]
    [ProducesResponseType(typeof(UserResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        var roleName = RoleNames.Normalise(request.Role);
        if (roleName is null)
            return ProblemResponse(400, "Invalid role", "Role must be either 'Organiser' or 'Participant'.");

        if (roleName == RoleNames.Organiser)
        {
            var expectedCode = _config["Registration:OrganiserCode"];
            if (string.IsNullOrWhiteSpace(expectedCode) ||
                !string.Equals(request.OrganiserCode, expectedCode, StringComparison.Ordinal))
            {
                return ProblemResponse(403, "Forbidden", "A valid organiser registration code is required to register as an Organiser.");
            }
        }

        var email = request.Email.Trim().ToLowerInvariant();
        if (await _db.Users.AnyAsync(u => u.Email == email))
            return ProblemResponse(409, "Conflict", "An account with this email address already exists.");

        var role = await _db.Roles.SingleAsync(r => r.RoleName == roleName);

        var user = new User
        {
            RoleId = role.RoleId,
            Role = role,
            FirstName = request.FirstName.Trim(),
            LastName = request.LastName.Trim(),
            Email = email,
            PhoneNumber = request.PhoneNumber?.Trim(),
            PasswordHash = _passwords.Hash(request.Password),
            CreatedAt = DateTime.Now
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        return Created("/api/users/me", user.ToResponse());
    }

    /// <summary>Logs a user in and starts a server-side session storing their user ID and role.</summary>
    /// <remarks>The session cookie returned is sent automatically on later requests (including from Swagger UI).</remarks>
    /// <response code="200">Login successful. Returns the user and their role.</response>
    /// <response code="401">Invalid email or password.</response>
    [HttpPost("login")]
    [ProducesResponseType(typeof(UserResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Email == email);

        // Same message for "unknown email" and "wrong password" so accounts cannot be enumerated.
        if (user is null || !_passwords.Verify(request.Password, user.PasswordHash))
            return ProblemResponse(401, "Unauthorized", "Invalid email or password.");

        await HttpContext.Session.LoadAsync();
        HttpContext.Session.Clear();
        HttpContext.Session.SetInt32(SessionKeys.UserId, user.UserId);
        HttpContext.Session.SetString(SessionKeys.Role, user.Role!.RoleName);
        await HttpContext.Session.CommitAsync();

        return Ok(user.ToResponse());
    }

    /// <summary>Ends the current session.</summary>
    /// <response code="200">Logged out.</response>
    /// <response code="401">No active session.</response>
    [HttpPost("logout")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return Ok(new MessageResponse("Logged out successfully."));
    }
}
