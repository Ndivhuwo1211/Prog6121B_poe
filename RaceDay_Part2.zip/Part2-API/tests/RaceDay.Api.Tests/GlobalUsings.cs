global using System.Net;
global using System.Net.Http.Json;
global using System.Text.Json;
global using Xunit;
global using static RaceDay.Api.Tests.TestHelpers;
